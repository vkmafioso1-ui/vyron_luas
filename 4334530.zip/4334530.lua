-- Generated with Luie @ https://lua.tools/
-- 4334530 - Cold Rails
-- Generated 2026-11-15 08:24:20 UTC
-- # Depots (Total/DLC/Shared): 4/1/0

-- Main AppID
addappid(4334530)

-- Main Depots
addappid(4334531, 1, "3423ebd522537ea997085ac60c757f04d8496b00fe5fd3d05558a178f0bc4fbb") -- (windows)
-- setManifestid(4334531, "4420728399491475543", 512801408)

-- Missing Depots (We don't have the keys yet lol): 4334532, 4334533, 5229831
