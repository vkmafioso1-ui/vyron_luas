-- 4954910's Lua and Manifest Created by Hubcap Manifest
-- Scam With Your Friends
-- Created: October 16, 2026 at 00:48:50 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 25977735 (public branch)
-- Build Date: October 16, 2026 at 00:20:31 EDT (1792124431)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4954910, 1, "8a9051a93f80aeeefb0ac0e26f3b230f513a03af0a2c27eb898fe2f905451443") -- Scam With Your Friends
-- MAIN APP DEPOTS
addappid(4954911, 1, "5ecd6cfa753bc263676f0dd579968e95d209b1e15363154df11fa51d51d4d94d") -- Depot 4954911
setManifestid(4954911, "2317744768457544272", 4672146405)