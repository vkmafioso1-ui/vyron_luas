-- Generated with Luie @ https://lua.tools/
-- 4607690 - Math-Havoc
-- Generated 2026-11-12 04:51:57 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4607690)

-- Main Depots
addappid(4607691, 1, "25cdb22ee222b83b83dd5476fac957891bf6460ba9e6f8e9b9c63db8942a8863") -- (windows)
setManifestid(4607691, "6989994899440427271", 68347895)
