-- Generated with Luie @ https://lua.tools/
-- 209160 - Call of Duty: Ghosts
-- Generated 2026-11-25 21:29:42 UTC
-- # Depots (Total/DLC/Shared): 14/0/12

-- Main AppID
addappid(209160, 1, "7ede47930d20ff25bf80d5a421b213de245f2e97bfd60171ab6a37b599011be2")

-- Main Depots
addappid(209161, 1, "6c5f97d6127289ac53c5c62d467652ef5ac48c597a8cdc0eccb13c2e0fc61520")
-- setManifestid(209161, "7048320834456545280", 13017351)
addappid(209163, 1, "add37e1da3d2ec3cbab0a8976f8bc8bf6ee91f7f3f80e33f2855434803b7dc3d")
-- setManifestid(209163, "3536227071105591070", 8068233883)

-- DLC's (no depot keys required)
addappid(259250) -- Call of Duty: Ghosts - Onslaught
addappid(259251) -- Call of Duty: Ghosts - Devastation
addappid(259252) -- Call of Duty: Ghosts - Invasion
addappid(259253) -- Call of Duty: Ghosts - Nemesis
addappid(268101) -- Call of Duty: Ghosts - Wolf Skin
addappid(277670) -- Call of Duty: Ghosts - Extra Slots Pack
addappid(277671) -- Call of Duty: Ghosts - Elias Character
addappid(277672) -- Call of Duty: Ghosts - Hesh Character
addappid(277673) -- Call of Duty: Ghosts - Merrick Character
addappid(277674) -- Call of Duty: Ghosts - Keegan Character
addappid(277675) -- Call of Duty: Ghosts - Price Legend Pack
addappid(277676) -- Call of Duty: Ghosts - Ducky Personalization Pack
addappid(277677) -- Call of Duty: Ghosts - Circuit Personalization Pack
addappid(277678) -- Call of Duty: Ghosts - Inferno Personalization Pack
addappid(277679) -- Call of Duty: Ghosts - Space Cats Personalization Pack
addappid(281340) -- Call of Duty: Ghosts - Makarov Legend Pack
addappid(281341) -- Call of Duty: Ghosts - Zakhaev Character
addappid(281342) -- Call of Duty: Ghosts - Rorke Character
addappid(281343) -- Call of Duty: Ghosts - Hazmat Character
addappid(281344) -- Call of Duty: Ghosts - 1987 Personalization Pack
addappid(281345) -- Call of Duty: Ghosts - Eyeballs Personalization Pack
addappid(281346) -- Call of Duty: Ghosts - Blunt Force Personalization Pack
addappid(281347) -- Call of Duty: Ghosts - Hex Personalization Pack
addappid(286630) -- Call of Duty: Ghosts - Heartlands Personalization Pack
addappid(286631) -- Call of Duty: Ghosts - Molten Personalization Pack
addappid(286632) -- Call of Duty: Ghosts - Soap Legend Pack
addappid(286633) -- Call of Duty: Ghosts - Squad Pack - Extinction
addappid(286634) -- Call of Duty: Ghosts - Classic Ghost Pack
addappid(286635) -- Call of Duty: Ghosts - Drill Instructor Voice Pack
addappid(286636) -- Call of Duty: Ghosts - Snoop Dogg Voice Pack
addappid(295430) -- Call of Duty: Ghosts - Bling Personalization Pack
addappid(295431) -- Call of Duty: Ghosts - Extinction Personalization Pack
addappid(295432) -- Call of Duty: Ghosts - Fitness Personalization Pack
addappid(295433) -- Call of Duty: Ghosts - Koi Personalization Pack
addappid(295434) -- Call of Duty: Ghosts - Heavy Metal Personalization Pack
addappid(295435) -- Call of Duty: Ghosts - Unicorn Personalization Pack
addappid(295436) -- Call of Duty: Ghosts - Spectrum Warrior
addappid(295437) -- Call of Duty: Ghosts - Astronaut Character
addappid(295438) -- Call of Duty: Ghosts - Squad Pack - Resistance
addappid(295439) -- Call of Duty: Ghosts - Leopard Personalization Pack
addappid(295440) -- Call of Duty: Ghosts - Abstract Personalization Pack
addappid(301110) -- Call of Duty: Ghosts - Flags of the World Pack
addappid(301111) -- Call of Duty: Ghosts - Hydra Personalization Pack 
addappid(301112) -- Call of Duty: Ghosts - Skulls Personalization Pack
addappid(301113) -- Call of Duty: Ghosts - Tattoo Personalization Pack
addappid(301114) -- Call of Duty: Ghosts - Nebula Personalization Pack
addappid(301115) -- Call of Duty: Ghosts - The Ripper
addappid(301116) -- Call of Duty: Ghosts - The Maverick
addappid(309870) -- Call of Duty: Ghosts - Blunt Force Character
addappid(309871) -- Call of Duty: Ghosts - Inferno Character
addappid(309872) -- Call of Duty: Ghosts - Bling Character

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(209162, 1, "cdd633e4566aa97be6819be3f4fbc1b21d160a0de33434c2af2297f87b916a71")
addappid(209172, 1, "16eb4ac87b73169c822cb7a30db1c37011cce5d1ca34cc43e14dbb7585225197") -- English
addappid(209173, 1, "3cf02f69392caa9e89071e2b6ba6e1bbf7fb383d08a913f7bd2678c340624169") -- French
addappid(209174, 1, "6e21fce437216efe571ceed63868eb344f20dd7a8115115f2c2ac0b838bc7e3b") -- Italian
addappid(209175, 1, "0b3b541bc5a337532b982da16da2012a68f1da7fc47c90f7f07279d480cb1548") -- German
addappid(209176, 1, "db712f754a1b50bafeb13f619b4e92f5f38713b891c86d2551666e9d720b9b74") -- Spanish
addappid(209177, 1, "c4978faa65e09265febdac5dd671c4e88064408765eea750c9ce42ffa560e324") -- Russian
addappid(209178, 1, "ea54f6a6fa67c6ad923f5339e1eeff609f9fbd034c98da0e221c2d74746acff4") -- Polish
addappid(209179, 1, "dad4e4db313dba7a14ec1a034a866fbb5ab949298d90c2d99b149a9dbe39a661") -- Japanese
addappid(209180, 1, "3f6bcef72a137e91f8ece3dcf3088cb38444abf895fdbdda579e59386b604ca9") -- Brazilian
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
