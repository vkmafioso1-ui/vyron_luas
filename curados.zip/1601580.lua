-- Generated with Luie @ https://lua.tools/
-- 1601580 - Frostpunk 2
-- Generated 2026-11-12 02:06:41 UTC
-- # Depots (Total/DLC/Shared): 16/11/3

-- Main AppID
addappid(1601580, 1, "b188b56eb26beef5cc8940334590f6202b960b404f64fc45efd499e5b8fa8446")
addtoken(1601580, "9776222650124242927")

-- Main Depots
addappid(1601581, 1, "7372485e88b89813dc5250dca3be72fcfa499604514bea173703fbb7bac1f78f") -- (windows)
setManifestid(1601581, "1112786033110687412", 22110601653)
addappid(1601582, 1, "430c4ff745d427259e5934cada320f38cfadad961bdb56a35f4403f2ffeaea6b") -- (macos)
setManifestid(1601582, "1620030169262753711", 18241196982)

-- DLC's (no depot keys required)
addappid(4065430) -- Frostpunk 2: Deluxe Edition Upgrade

-- DLC's (with depot keys)
-- Frostpunk 2: Digital Artbook & “Warm Flesh” Novella  (AppID: 2791490)
addappid(2791490)
addtoken(2791490, "2460618430796516304")
addappid(2791490, 1, "3f4b6f54645a56bc7991b93bed90155b81354f90e7fb4113e92ed9378980e36c") -- (64-bit)
setManifestid(2791490, "5534266034783623960", 262961032)
-- Frostpunk 2: “Captain's Hall” In-game Item (AppID: 2791500)
addappid(2791500)
addtoken(2791500, "17920453012318309804")
addappid(1601583, 1, "be06bc27eb3b8e788a06bae787211c5e406cf846a3aeceffbac54475a447d036") -- (macos)
setManifestid(1601583, "1556554617951712131", 18241196976)
addappid(2791500, 1, "647f22682ffa05f21b1ea12779b04414782ddf4f2456565761b6ee0f863204ee") -- (windows, 64-bit)
setManifestid(2791500, "4473289431149296091", 147450870)
-- Frostpunk 2: Fractured Utopias (AppID: 2791510)
addappid(2791510)
addappid(1601584, 1, "36e9a475072dc9722c31a1fb0e453b8059561f32f293e4fe0b23016f5243ee2d") -- (macos)
setManifestid(1601584, "6328326313015819129", 0)
addappid(2791510, 1, "ffad03667e8754d84e3dc4638c128fab65e760710bb056d2296e53c6c6de50bd") -- (windows, 64-bit)
setManifestid(2791510, "8755351809277204459", 1237640181)
-- Frostpunk 2: Original Soundtrack (AppID: 3197520)
addappid(3197520)
addtoken(3197520, "7349154432839621830")
addappid(3197521, 1, "66056a852f67cada4c33cab907e25d35ce77d8bba7ea53ba58d77f61d4f70386")
setManifestid(3197521, "1715674255709004417", 221269211)
addappid(3197522, 1, "da29c80aa2aba4348ddab91f90fc9c93c5b931b1b84f2ed317aa61b8c62bc0f7")
setManifestid(3197522, "7333279036358424805", 4772769846)
-- Frostpunk 2: Breach of Trust (AppID: 4124750)
addappid(4124750)
addappid(4124750, 1, "019eed088b74a71ab2144e9bd30f2b2c49a8c2337683ea8c5e5b3c378da5d2f9") -- (windows, 64-bit)
setManifestid(4124750, "3410021992439246931", 799685388)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- Missing Depots (We don't have the keys yet lol): 1601585, 1601586, 4124760
