-- Generated with Luie @ https://lua.tools/
-- 2871520 - Deep Dish Dungeon
-- Generated 2026-11-09 07:05:08 UTC
-- # Depots (Total/DLC/Shared): 2/0/0

-- Main AppID
addappid(2871520)

-- Main Depots
addappid(2871521, 1, "4e731b73a8e41aed9ebcbac9f9229a91af3a1e08bba1f48bb9abfb31e2e71d91") -- (windows)
setManifestid(2871521, "2901143451768783124", 672634894)

-- Missing Depots (We don't have the keys yet lol): 2871522
