-- Generated with Luie @ https://lua.tools/
-- 1676840 - For The King II
-- Generated 2026-11-12 04:05:19 UTC
-- # Depots (Total/DLC/Shared): 3/2/0

-- Main AppID
addappid(1676840, 1, "f3c36152c17092f6ddc490bbc44dbba14f61628d8e7bbec1994957a5136513ae")

-- Main Depots
addappid(1676841, 1, "9e9bc5c19be892894290e7c750d0e94ab08b89d76dcf20f675df2bf99bd19b58") -- (windows, 64-bit)
setManifestid(1676841, "3829213164447498873", 10416100308)

-- DLC's (no depot keys required)
addappid(2594240) -- For The King II - Primordial Content Pack
addappid(3840390) -- For The King II: Tinkerers Of Fate Character Pack
addappid(3840400) -- For The King II: Fallen Oaths Character Pack
addappid(4354810) -- For The King II: Into The Wild Character Pack
addappid(4856240) -- For The King II: Smoke & Steel Cosmetic Pack
addappid(5169060) -- For The King II: Dust to Dust Character Pack

-- DLC's (with depot keys)
-- For The King II - Original Game Soundtrack (AppID: 2594250)
addappid(2594250)
addappid(2594251, 1, "0cd2ed767362e21fcd1efc1835e2adf39075223a4c4461c4eeff5dd43bd0ca8c")
setManifestid(2594251, "5337971465841178251", 134961379)
addappid(2594252, 1, "904bc5b60e3c3008b667ba7fddfbcf9bff0abd503b4b54ee9bfab5a24981087c")
setManifestid(2594252, "9051611012477840950", 1919974808)
