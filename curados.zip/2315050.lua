-- Generated with Luie @ https://lua.tools/
-- 2315050 - We Were Here Tomorrow
-- Generated 2026-11-09 05:23:37 UTC
-- # Depots (Total/DLC/Shared): 4/3/0

-- Main AppID
addappid(2315050, 1, "291c28e8ff68430911bae98362a2ed22dc5220f438f236dee5c90b9538baa654")

-- Main Depots
addappid(2315051, 1, "39c790041d1581be366a3fddbb90ce4d099ed9253af155e08352106faa831339") -- (windows, 64-bit)
-- setManifestid(2315051, "633411287096783264", 21374946057)

-- DLC's (with depot keys)
-- We Were Here Tomorrow: Fan Edition (AppID: 5202830)
addappid(5202830)
addappid(5202830, 1, "c0489ec79666b4b10cc7a851f6222749fd672070d2be8c104e1bf440c8b3b31d")
-- setManifestid(5202830, "7023124551390925896", 351962420)

-- Missing Depots (We don't have the keys yet lol): 5202801, 5202802
