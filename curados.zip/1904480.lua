-- Generated with Luie @ https://lua.tools/
-- 1904480 - Absolum
-- Generated 2026-11-12 04:20:47 UTC
-- # Depots (Total/DLC/Shared): 4/2/1

-- Main AppID
addappid(1904480, 1, "0af2c99f19603642021fffda7d5d95ac03f6b9b5426776add99de302aee3efb0")

-- Main Depots
addappid(1904481, 1, "119d51fd44dd8198b1a6c12a73e3943c8587d93e990f15b7453404b51a8ce4f3")
setManifestid(1904481, "4229612714462700351", 4881076479)

-- DLC's (with depot keys)
-- Absolum (Original Game Soundtrack) (AppID: 3812410)
addappid(3812410)
addappid(3812411, 1, "0ac2d57606b5b0e2c778ae4f9f7ade0e01941d73a9fcaa1bee1eec16b3b9d9d1")
setManifestid(3812411, "1975252275178417104", 133431206)
addappid(3812414, 1, "9097694c6e5eb08331c079931bbb94099cd644883674d006270dd26f46ca85dd")
setManifestid(3812414, "4601597969254808548", 2413372042)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
